import React, { useState, useCallback, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Home, PiggyBank, BarChart3, Settings, ChevronDown, Bell, User, PlusCircle, ArrowRight, Bot, Banknote, TrendingUp, TrendingDown, Wallet, LogIn, UserPlus, Eye, EyeOff, X } from 'lucide-react';

// --- Mock Data (to be replaced later) ---
const spendingTrendsData = [
  { name: 'Week 1', expenses: 400, income: 600 },
  { name: 'Week 2', expenses: 300, income: 500 },
  { name: 'Week 3', expenses: 500, income: 750 },
  { name: 'Week 4', expenses: 450, income: 700 },
];
const spendingByCategoryData = [
  { name: 'Groceries', spent: 400 },
  { name: 'Transport', spent: 150 },
  { name: 'Entertainment', spent: 200 },
  { name: 'Utilities', spent: 250 },
  { name: 'Shopping', spent: 300 },
];
const expenseBreakdownData = [
  { name: 'Groceries', value: 400 },
  { name: 'Transport', value: 150 },
  { name: 'Entertainment', value: 200 },
  { name: 'Utilities', value: 250 },
  { name: 'Shopping', value: 300 },
];
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF'];
const recentTransactions = [
  { id: 1, description: 'Netflix Subscription', category: 'Entertainment', amount: -15.99, date: '2025-08-22' },
  { id: 2, description: 'Grocery Store', category: 'Groceries', amount: -76.54, date: '2025-08-21' },
  { id: 3, description: 'Freelance Payment', category: 'Income', amount: 1200.00, date: '2025-08-21' },
  { id: 4, description: 'Gas Station', category: 'Transport', amount: -45.30, date: '2025-08-20' },
  { id: 5, description: 'Electricity Bill', category: 'Utilities', amount: -112.80, date: '2025-08-19' },
];
const budgets = [
    { id: 1, name: 'Groceries', allocated: 500, spent: 400, remaining: 100 },
    { id: 2, name: 'Shopping', allocated: 400, spent: 300, remaining: 100 },
    { id: 3, name: 'Entertainment', allocated: 250, spent: 200, remaining: 50 },
    { id: 4, name: 'Transport', allocated: 200, spent: 150, remaining: 50 },
];

// --- API Configuration ---
const API_BASE_URL = 'http://127.0.0.1:3000';

// --- Gemini API Helper ---
const callGeminiAPI = async (prompt, schema) => {
    const apiKey = ""; // This will be handled by the environment
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${apiKey}`;
    
    const payload = {
        contents: [{ role: "user", parts: [{ text: prompt }] }],
    };

    if (schema) {
        payload.generationConfig = {
            responseMimeType: "application/json",
            responseSchema: schema,
        };
    }

    let retries = 3;
    let delay = 1000;

    while (retries > 0) {
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            
            if (result.candidates && result.candidates.length > 0 &&
                result.candidates[0].content && result.candidates[0].content.parts &&
                result.candidates[0].content.parts.length > 0) {
                const text = result.candidates[0].content.parts[0].text;
                return text;
            } else {
                throw new Error("Unexpected API response structure");
            }

        } catch (error) {
            console.error("Gemini API call failed:", error);
            retries--;
            if (retries === 0) throw error;
            await new Promise(resolve => setTimeout(resolve, delay));
            delay *= 2; // Exponential backoff
        }
    }
};


// --- Authentication Components ---

const AuthForm = ({ isRegister = false, onAuthSuccess }) => {
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setIsLoading(true);

        if (isRegister) {
            // --- Registration Logic ---
            try {
                const response = await fetch(`${API_BASE_URL}/api/register`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        full_name: fullName,
                        email,
                        password,
                    }),
                });
                const data = await response.json();
                if (!response.ok) throw new Error(data.error || 'Registration failed');
                alert('Registration successful! Please log in.');
                window.location.reload(); 
            } catch (err) {
                setError(err.message);
            } finally {
                setIsLoading(false);
            }
        } else {
            // --- Login Logic (Placeholder) ---
            setTimeout(() => {
                if (email === "test@test.com" && password === "password") {
                    onAuthSuccess({ name: 'Alex Doe' });
                } else {
                    setError('Invalid credentials. (Use test@test.com and password)');
                }
                setIsLoading(false);
            }, 1000);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            {isRegister && (
                <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                    <div className="mt-1">
                        <input id="fullName" name="fullName" type="text" required value={fullName} onChange={e => setFullName(e.target.value)} className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                    </div>
                </div>
            )}
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email address</label>
                <div className="mt-1">
                    <input id="email" name="email" type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                </div>
            </div>
            <div>
                <label htmlFor="password"className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
                <div className="mt-1 relative">
                    <input id="password" name="password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" required value={password} onChange={e => setPassword(e.target.value)} className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500">
                        {showPassword ? <EyeOff /> : <Eye />}
                    </button>
                </div>
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <div>
                <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300">
                    {isLoading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : (isRegister ? 'Create Account' : 'Sign In')}
                </button>
            </div>
        </form>
    );
};

const AuthPage = ({ onAuthSuccess }) => {
    const [isRegisterView, setIsRegisterView] = useState(false);
    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
            <div className="sm:mx-auto sm:w-full sm:max-w-md">
                <div className="flex justify-center items-center">
                    <Wallet className="w-12 h-12 text-blue-600" />
                    <h2 className="ml-4 text-center text-3xl font-extrabold text-gray-900 dark:text-white">FinForecast AI</h2>
                </div>
            </div>
            <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
                <div className="bg-white dark:bg-gray-800 py-8 px-4 shadow-xl sm:rounded-lg sm:px-10">
                    <div className="mb-6"><h3 className="text-xl font-bold text-center text-gray-800 dark:text-gray-200">{isRegisterView ? 'Create a new account' : 'Sign in to your account'}</h3></div>
                    <AuthForm isRegister={isRegisterView} onAuthSuccess={onAuthSuccess} />
                    <div className="mt-6"><div className="relative"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-300 dark:border-gray-600" /></div><div className="relative flex justify-center text-sm"><span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">Or</span></div></div>
                        <div className="mt-6 text-center">
                            <button onClick={() => setIsRegisterView(!isRegisterView)} className="font-medium text-blue-600 hover:text-blue-500">
                                {isRegisterView ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- Main App Components (Dashboard, etc.) ---

const Header = ({ userName, onLogout }) => (
  <header className="bg-white dark:bg-gray-800 shadow-sm p-4 flex justify-between items-center">
    <h1 className="text-2xl font-bold text-gray-800 dark:text-white">FinForecast AI</h1>
    <div className="flex items-center space-x-4">
      <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"><Bell className="w-6 h-6 text-gray-600 dark:text-gray-300" /></button>
      <div className="relative group">
        <div className="flex items-center space-x-2 cursor-pointer">
            <User className="w-8 h-8 rounded-full bg-gray-200 text-gray-600 p-1" />
            <span className="hidden md:block font-medium text-gray-700 dark:text-gray-200">{userName}</span>
            <ChevronDown className="w-5 h-5 text-gray-500" />
        </div>
        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all duration-200">
            <a href="#" onClick={(e) => { e.preventDefault(); onLogout(); }} className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700">Sign out</a>
        </div>
      </div>
    </div>
  </header>
);

const Sidebar = ({ currentPage, onNavClick }) => {
    const navItems = [
        { id: 'dashboard', label: 'Dashboard', icon: Home },
        { id: 'budgets', label: 'Budgets', icon: PiggyBank },
        { id: 'forecast', label: 'Forecast', icon: BarChart3 },
        { id: 'settings', label: 'Settings', icon: Settings },
    ];
    return (
        <aside className="w-16 md:w-64 bg-white dark:bg-gray-800 flex flex-col transition-all duration-300">
            <div className="h-16 flex items-center justify-center md:justify-start md:px-6 border-b dark:border-gray-700">
                 <Wallet className="w-8 h-8 text-blue-600" /><span className="hidden md:block ml-3 text-xl font-bold text-gray-800 dark:text-white">FinForecast</span>
            </div>
            <nav className="flex-1 px-2 md:px-4 py-4 space-y-2">
                {navItems.map(item => (
                    <a key={item.id} href="#" onClick={(e) => { e.preventDefault(); onNavClick(item.id); }}
                        className={`flex items-center p-3 rounded-lg transition-colors ${ currentPage === item.id ? 'bg-blue-500 text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
                        <item.icon className="w-6 h-6" /><span className="hidden md:block ml-4 font-medium">{item.label}</span>
                    </a>
                ))}
            </nav>
        </aside>
    );
};

const SummaryCard = ({ title, value, icon, change, changeType }) => {
    const Icon = icon;
    const isPositive = changeType === 'positive';
    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md flex items-center justify-between">
            <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-white">{value}</p>
                 {change && (<div className={`text-sm flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>{isPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}<span>{change} vs last month</span></div>)}
            </div>
            <div className="bg-blue-100 dark:bg-blue-900/50 p-3 rounded-full"><Icon className="w-6 h-6 text-blue-600 dark:text-blue-400" /></div>
        </div>
    );
};

const ChartCard = ({ title, children }) => (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">{title}</h3>
        <div style={{ width: '100%', height: 300 }}><ResponsiveContainer>{children}</ResponsiveContainer></div>
    </div>
);

const DashboardPage = () => (
    <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <SummaryCard title="Total Balance" value="$12,450.78" icon={Wallet} change="+5.2%" changeType="positive" />
            <SummaryCard title="Monthly Income" value="$4,800.00" icon={Banknote} change="+2.1%" changeType="positive"/>
            <SummaryCard title="Monthly Expenses" value="$1,950.22" icon={TrendingDown} change="-1.5%" changeType="positive"/>
            <SummaryCard title="Savings Rate" value="59%" icon={PiggyBank} change="+3.7%" changeType="positive"/>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ChartCard title="Spending Trends (Last 4 Weeks)"><LineChart data={spendingTrendsData}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(200, 200, 200, 0.3)" /><XAxis dataKey="name" /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="income" stroke="#82ca9d" strokeWidth={2} name="Income" /><Line type="monotone" dataKey="expenses" stroke="#8884d8" strokeWidth={2} name="Expenses" /></LineChart></ChartCard>
            <ChartCard title="Spending by Category"><BarChart data={spendingByCategoryData}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(200, 200, 200, 0.3)"/><XAxis dataKey="name" /><YAxis /><Tooltip /><Bar dataKey="spent" fill="#8884d8" name="Amount Spent" /></BarChart></ChartCard>
        </div>
    </div>
);

const BudgetCategory = ({ name, allocated, spent }) => {
    const percentage = Math.min((spent / allocated) * 100, 100);
    const progressBarColor = percentage > 90 ? 'bg-red-500' : percentage > 75 ? 'bg-yellow-500' : 'bg-green-500';
    return (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-center mb-2"><span className="font-semibold text-gray-800 dark:text-white">{name}</span><span className="text-sm text-gray-500 dark:text-gray-400">${spent.toFixed(2)} / ${allocated.toFixed(2)}</span></div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5"><div className={`${progressBarColor} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div></div>
            <div className="text-right text-xs text-gray-500 dark:text-gray-400 mt-1">${(allocated - spent).toFixed(2)} remaining</div>
        </div>
    );
};

const AIBudgetModal = ({ onClose, onBudgetGenerated }) => {
    const [income, setIncome] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleGenerate = async () => {
        if (!income || isNaN(income)) {
            setError('Please enter a valid monthly income.');
            return;
        }
        setIsLoading(true);
        setError(null);

        const prompt = `Based on a monthly income of $${income}, create a simple budget plan using the 50/30/20 rule (50% needs, 30% wants, 20% savings/debt). Provide a breakdown of common categories for needs and wants.`;
        const schema = {
            type: "ARRAY",
            items: {
                type: "OBJECT",
                properties: {
                    category: { type: "STRING" },
                    amount: { type: "NUMBER" },
                    type: { type: "STRING", enum: ["Needs", "Wants", "Savings"] }
                },
                required: ["category", "amount", "type"]
            }
        };

        try {
            const responseText = await callGeminiAPI(prompt, schema);
            const generatedPlan = JSON.parse(responseText);
            onBudgetGenerated(generatedPlan);
            onClose();
        } catch (err) {
            setError('Failed to generate budget. Please try again.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-8 w-full max-w-md m-4">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-white">✨ AI Budget Planner</h2>
                    <button onClick={onClose}><X className="w-6 h-6 text-gray-500" /></button>
                </div>
                <p className="text-gray-600 dark:text-gray-300 mb-4">Enter your total monthly income, and our AI will suggest a budget plan for you.</p>
                <div>
                    <label htmlFor="income" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Monthly Income ($)</label>
                    <input id="income" type="number" value={income} onChange={(e) => setIncome(e.target.value)} placeholder="e.g., 4800" className="mt-1 w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                </div>
                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                <div className="mt-6 flex justify-end">
                    <button onClick={handleGenerate} disabled={isLoading} className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-300 flex items-center">
                        {isLoading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div> : null}
                        {isLoading ? 'Generating...' : 'Generate Plan'}
                    </button>
                </div>
            </div>
        </div>
    );
};

const BudgetsPage = () => {
    const [showAIModal, setShowAIModal] = useState(false);
    const [generatedBudgets, setGeneratedBudgets] = useState(null);

    return (
        <div className="p-6">
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Your Budgets</h2>
                <div className="flex gap-2">
                     <button onClick={() => setShowAIModal(true)} className="flex items-center bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                        ✨ Generate Budget with AI
                    </button>
                    <button className="flex items-center bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                        <PlusCircle className="w-5 h-5 mr-2" />
                        Add Manually
                    </button>
                </div>
            </div>

            {generatedBudgets && (
                 <div className="mb-8 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
                    <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">✨ AI Suggested Plan</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {generatedBudgets.map((b, i) => (
                            <div key={i} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                                <p className="font-bold text-gray-800 dark:text-gray-200">{b.category}</p>
                                <p className="text-lg text-blue-600 dark:text-blue-400">${b.amount.toFixed(2)}</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">{b.type}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Current Budgets</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {budgets.map(budget => (
                    <BudgetCategory key={budget.id} name={budget.name} allocated={budget.allocated} spent={budget.spent} />
                ))}
            </div>
            {showAIModal && <AIBudgetModal onClose={() => setShowAIModal(false)} onBudgetGenerated={setGeneratedBudgets} />}
        </div>
    );
};

const ForecastPage = () => {
    const [query, setQuery] = useState('');
    const [response, setResponse] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleQuery = async () => {
        if (!query) return;
        setIsLoading(true);
        setResponse('');
        setError(null);

        const context = "User's financial summary: Monthly Income: $4,800. Monthly Expenses: $1,950.";
        const prompt = `You are a helpful financial assistant. ${context} Answer the user's question in a concise and encouraging tone: "${query}"`;

        try {
            const apiResponse = await callGeminiAPI(prompt);
            setResponse(apiResponse);
        } catch (err) {
            setError("Sorry, I couldn't get a response. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-6 space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Financial Forecast</h2>
            <ChartCard title="Projected Account Balance (Next 6 Months)">
                <LineChart data={[ { name: 'Aug', balance: 12450 }, { name: 'Sep', balance: 14000 }, { name: 'Oct', balance: 15500 }, { name: 'Nov', balance: 17200 }, { name: 'Dec', balance: 19000 }, { name: 'Jan', balance: 21000 }, ]}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(200, 200, 200, 0.3)"/>
                    <XAxis dataKey="name" />
                    <YAxis domain={['dataMin - 1000', 'dataMax + 1000']} />
                    <Tooltip />
                    <Line type="monotone" dataKey="balance" stroke="#8884d8" strokeWidth={2} name="Projected Balance" />
                </LineChart>
            </ChartCard>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
                    <Bot className="w-6 h-6 mr-2 text-blue-500" />
                    ✨ AI Financial Assistant
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">Ask a question about your finances, and our AI will provide insights.</p>
                <div className="flex flex-col sm:flex-row gap-2">
                    <input type="text" value={query} onChange={(e) => setQuery(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleQuery()}
                        placeholder="e.g., How can I save an extra $200 per month?"
                        className="flex-grow p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                    <button onClick={handleQuery} disabled={isLoading} className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-blue-300 flex items-center justify-center">
                        {isLoading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <ArrowRight className="w-5 h-5" />}
                    </button>
                </div>
                 {error && <p className="text-red-500 text-sm mt-4">{error}</p>}
                {response && (
                    <div className="mt-4 p-4 bg-blue-50 dark:bg-gray-700/50 rounded-lg">
                        <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap">{response}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

const SettingsPage = () => (
    <div className="p-6 space-y-8">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Settings</h2>
    </div>
);


// --- Main Application Shell ---

const AuthenticatedApp = ({ user, onLogout }) => {
    const [currentPage, setCurrentPage] = useState('dashboard');
    const handleNavClick = useCallback((page) => setCurrentPage(page), []);

    const renderPage = () => {
        switch (currentPage) {
            case 'dashboard': return <DashboardPage />;
            case 'budgets': return <BudgetsPage />;
            case 'forecast': return <ForecastPage />;
            case 'settings': return <SettingsPage />;
            default: return <DashboardPage />;
        }
    };

    return (
        <div className="flex h-screen bg-gray-100 dark:bg-gray-900 font-sans">
            <Sidebar currentPage={currentPage} onNavClick={handleNavClick} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header userName={user.name} onLogout={onLogout} />
                <main className="flex-1 overflow-x-hidden overflow-y-auto">
                    {renderPage()}
                </main>
            </div>
        </div>
    );
};

export default function App() {
    const [user, setUser] = useState(null);

    const handleLoginSuccess = (userData) => {
        setUser(userData);
    };

    const handleLogout = () => {
        setUser(null);
    };

    if (!user) {
        return <AuthPage onAuthSuccess={handleLoginSuccess} />;
    }

    return <AuthenticatedApp user={user} onLogout={handleLogout} />;
}