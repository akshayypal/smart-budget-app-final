-- Add migration script here
-- migrations/YYYYMMDDHHMMSS_create_budgets_table.sql

CREATE TABLE budgets (
    budget_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    category VARCHAR(100) NOT NULL,
    allocated_amount NUMERIC(15, 2) NOT NULL,
    budget_month DATE NOT NULL,
    UNIQUE(user_id, category, budget_month)
);