use axum::{
    extract::State,
    http::StatusCode,
    response::Json,
    routing::{get, post},
    Router,
};
use bcrypt::{hash, verify, DEFAULT_COST};
use dotenvy::dotenv;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sqlx::{postgres::PgPoolOptions, PgPool};
use std::env;
use std::net::SocketAddr;
use tower_http::cors::{Any, CorsLayer};
use uuid::Uuid;

// --- Data Models ---

#[derive(Debug, Deserialize)]
struct RegisterUserPayload {
    email: String,
    password: String,
    full_name: String,
}

#[derive(Debug, Serialize)]
struct UserResponse {
    user_id: Uuid,
    email: String,
    full_name: Option<String>,
}

#[derive(Debug, Deserialize)]
struct LoginPayload {
    email: String,
    password: String,
}

// --- Main Application ---
#[tokio::main]
async fn main() {
    dotenv().ok();
    let database_url = env::var("DATABASE_URL").expect("DATABASE_URL must be set");

    let pool = PgPoolOptions::new()
        .max_connections(5)
        .connect(&database_url)
        .await
        .expect("Failed to create database connection pool.");
    println!("✅ Database connection successful");

    let cors = CorsLayer::new().allow_origin(Any).allow_methods(Any).allow_headers(Any);

    // Define our API routes
    let api_routes = Router::new()
        .route("/register", post(register_user_handler))
        .route("/login", post(login_user_handler))   // 👈 added login route
        .route("/health", get(health));

    let app = Router::new()
        .route("/", get(root))
        .nest("/api", api_routes)
        .with_state(pool)
        .layer(cors);

    let addr = SocketAddr::from(([127, 0, 0, 1], 3000));
    println!("✅ Server started successfully, listening on http://{}", addr);

    let listener = tokio::net::TcpListener::bind(&addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

// --- Route Handlers ---

async fn root() -> &'static str {
    "Welcome to the Smart Budget API"
}

async fn health() -> &'static str {
    "OK"
}

// Registration
async fn register_user_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<RegisterUserPayload>,
) -> (StatusCode, Json<Value>) {
    let hashed_password = match hash(&payload.password, DEFAULT_COST) {
        Ok(h) => h,
        Err(_) => {
            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(json!({"error": "Failed to hash password"})),
            );
        }
    };

    let user_result = sqlx::query_as!(
        UserResponse,
        "INSERT INTO users (email, password_hash, full_name) 
         VALUES ($1, $2, $3) 
         RETURNING user_id, email, full_name",
        payload.email.to_lowercase(),
        hashed_password,
        payload.full_name
    )
    .fetch_one(&pool)
    .await;

    match user_result {
        Ok(user) => {
            let response_body = json!({
                "status": "success",
                "data": user
            });
            (StatusCode::CREATED, Json(response_body))
        }
        Err(e) => {
            if e.to_string().contains("duplicate key value violates unique constraint") {
                return (
                    StatusCode::CONFLICT,
                    Json(json!({"error": "A user with this email already exists."})),
                );
            }
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(json!({"error": "Failed to register user."})),
            )
        }
    }
}

// Login
async fn login_user_handler(
    State(pool): State<PgPool>,
    Json(payload): Json<LoginPayload>,
) -> (StatusCode, Json<Value>) {
    let user_result = sqlx::query!(
        "SELECT user_id, email, password_hash, full_name FROM users WHERE email = $1",
        payload.email.to_lowercase()
    )
    .fetch_optional(&pool)
    .await;

    match user_result {
        Ok(Some(user)) => {
            let is_valid = verify(&payload.password, &user.password_hash).unwrap_or(false);

            if is_valid {
                (
                    StatusCode::OK,
                    Json(json!({
                        "success": true,
                        "email": user.email,
                        "full_name": user.full_name,
                        "error": null
                    })),
                )
            } else {
                (
                    StatusCode::UNAUTHORIZED,
                    Json(json!({
                        "success": false,
                        "email": user.email,
                        "full_name": null,
                        "error": "Invalid password"
                    })),
                )
            }
        }
        Ok(None) => (
            StatusCode::NOT_FOUND,
            Json(json!({
                "success": false,
                "email": payload.email,
                "full_name": null,
                "error": "User not found"
            })),
        ),
        Err(_) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({
                "success": false,
                "email": payload.email,
                "full_name": null,
                "error": "Database error"
            })),
        ),
    }
}
